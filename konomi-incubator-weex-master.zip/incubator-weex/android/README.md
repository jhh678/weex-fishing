# Build from source
## Install gradlew   
  See https://gradle.org/install#with-a-package-manager
## Build Weex   
run `gradle build`   
Playground app artifact will be under 'playground/app/build'
