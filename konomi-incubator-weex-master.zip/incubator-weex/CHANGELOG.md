## [Unreleased]

### Changed
- [android]Move DOM and render to seperate Action Object
- [android]Move Animation(animation module and css style) to seperate Action Object
- [android]Reserve `transformOrigin`'s last time state.
- [android]Refactor list-component sticky, use `List` instead of `Stack` to store sticky information.
